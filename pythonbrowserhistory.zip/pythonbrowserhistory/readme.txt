The exe file retrieves the end users Browser history currently works for Chrome but can also be used for safari and firefox.
It then sends the browser history to the email(find the email details below)
every hour and attaches the users browser history in csv format.
-----------------------------------------
After running the exe file it starts in the backgorund without the user knowing and to stop the exe open the taskmanager and end the exe.

----------------------------------------
Email Id scriptspython25@gmail.com
password Python@123


Abhijot chadha
Note: It can run on any windows machine whithout installing python.   